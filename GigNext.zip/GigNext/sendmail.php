
    <?php



    include("/xampp/htdocs/GigNext/components/conn.php");
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        require 'PHPMailer/PHPMailerAutoload.php';
        require 'credential.php';

        $mail = new PHPMailer;
        $usermail = $_POST['email'];
        $parts = explode("@", $_POST['email']);
        $username = $parts[0];

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = EMAIL;
        $mail->Password = PASS;
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom(EMAIL, 'GigNext ltd');
        $mail->addAddress($usermail, $username);
echo"<pre>";

        $mail->isHTML(true);

        $stmt = $con->prepare("INSERT INTO subscribed_emails (email) VALUES(?)");
        $stmt->bind_param("s", $usermail);
        try {
            if ($stmt->execute()) {
                echo "Subscription successful";
            }
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() === 1062) { // MySQL duplicate entry error code
                echo "Email already subscribed";
            } else {
                echo "Error: " . $e->getMessage();
            }
        }


        $mail->Subject = "new message";
        $mail->Body    = '<div style="margin: 50px auto;
			background-color: #fff;
			padding: 20px;
			border-radius: 8px;
			border: black;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">' . 'u have successfully subscribed to daily newsletter<br><h3>THANK YOU</h3>' . '</div>';
        $mail->AltBody = "u have successfully subscribed to daily newsletter<br><h3>THANK YOU</h3>";

        if (!$mail->send()) {
            echo "retry";
        } else {
            echo "<br>subscribed";
        }
    }

    echo "</pre>";
    mysqli_close($con);

    ?>
