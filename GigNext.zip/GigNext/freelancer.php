<?php
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: login_n_signup.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <!-- Webpage Title -->
    <title>GigNext - Freelancers Market</title>

    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="./css/bootstrap.min.css" rel="stylesheet">
    <link href="./css/fontawesome-all.min.css" rel="stylesheet">
    <link href="./css/aos.min.css" rel="stylesheet">
    <link href="./css/swiper.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" href="./assets/images/favicon.png">
</head>

<body>

    <!-- Navigation -->
    <nav id="navbar" class="navbar navbar-expand-lg fixed-top navbar-dark" aria-label="Main navigation">
        <div class="container">

            <!-- Image Logo -->
            <!-- <a class="navbar-brand logo-image" href="index.php"><img src="images/logo.svg" alt="alternative"></a> -->

            <!-- Text Logo - Use this if you don't have a graphic logo -->
            <a class="navbar-brand logo-text" href="index.php">GigNext</a>

            <button class="navbar-toggler p-0 border-0" type="button" id="navbarSideCollapse" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ms-auto navbar-nav-scroll">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user.php">Hire</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="freelancer.php">earn money</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" id="dropdown01" data-bs-toggle="dropdown" aria-expanded="false" href="#">Drop</a>

                        <ul class="dropdown-menu" aria-labelledby="dropdown01">
                            <li><a class="dropdown-item" href="article.php">Article Details</a></li>
                            <li>
                                <div class="dropdown-divider"></div>
                            </li>
                            <li><a class="dropdown-item" href="terms.php">Terms Conditions</a></li>
                            <li>
                                <div class="dropdown-divider"></div>
                            </li>
                            <li><a class="dropdown-item" href="privacy.php">Privacy Policy</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact</a>
                    </li>

                    <?php
                    session_start();
                    if (!isset($_SESSION["username"])) {
                header("location: index.php");
            ?>
                       
            <?php
                    } else {
            ?>
                <li><a class="btn btn-primary me-2" href="logout.php">Logout</a></li>
            <?php

                    }

            ?>



            </div> <!-- end of navbar-collapse -->
        </div> <!-- end of container -->
    </nav> <!-- end of navbar -->
    <!-- end of navigation -->


    <!-- Home -->


    <section class="contact d-flex align-items-center py-5" id="my=projects">

        <div class="container mt-5">
            <h2 class="text-center mb-4">Newly Arrived Projects</h2>
            <div class="row">
                <!-- Project Card 1 -->
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">E-commerce Website</h5>
                            <p class="card-text"><strong>Client:</strong> Alice Johnson</p>
                            <p class="card-text">Develop a fully functional e-commerce website.</p>
                            <p class="card-text"><strong>Budget:</strong> $10,000</p>
                            <a href="#" class="btn btn-primary">Accept</a>
                        </div>
                    </div>
                </div>

                <!-- Project Card 2 -->
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Blog Content Creation</h5>
                            <p class="card-text"><strong>Client:</strong> Bob Smith</p>
                            <p class="card-text">Write and publish 10 blog posts for the client.</p>
                            <p class="card-text"><strong>Budget:</strong> $3,000</p>
                            <a href="#" class="btn btn-primary">Accept</a>
                        </div>
                    </div>
                </div>

                <!-- Project Card 3 -->
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Mobile App Development</h5>
                            <p class="card-text"><strong>Client:</strong> Charlie Brown</p>
                            <p class="card-text">Create a mobile app for iOS and Android.</p>
                            <p class="card-text"><strong>Budget:</strong> $15,000</p>
                            <a href="#" class="btn btn-primary">Accept</a>
                        </div>
                    </div>
                </div>

                <!-- Project Card 4 -->
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Data Analysis Project</h5>
                            <p class="card-text"><strong>Client:</strong> Diana Prince</p>
                            <p class="card-text">Analyze sales data and provide insights.</p>
                            <p class="card-text"><strong>Budget:</strong> $5,000</p>
                            <a href="#" class="btn btn-primary">Accept</a>
                        </div>
                    </div>
                </div>

                <!-- Project Card 5 -->
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">SEO Optimization</h5>
                            <p class="card-text"><strong>Client:</strong> Alice Johnson</p>
                            <p class="card-text">Optimize the website for search engines.</p>
                            <p class="card-text"><strong>Budget:</strong> $2,000</p>
                            <a href="#" class="btn btn-primary">Accept</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    </section>



    <!-- my projects -->
    <section class="contact d-flex align-items-center py-5" id="my=projects">
        <div class="container py-4" data-aos="fade-right">
            <!-- Status Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="card status-card border-start border-primary border-4 h-100">
                        <div class="card-body">
                            <h5 class="card-title text-primary">All Projects</h5>
                            <h3 class="fw-bold">42</h3>
                            <p class="text-muted mb-0">Total Projects</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card status-card border-start border-success border-4 h-100">
                        <div class="card-body">
                            <h5 class="card-title text-success">Completed</h5>
                            <h3 class="fw-bold">18</h3>
                            <p class="text-muted mb-0">Finished Projects</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card status-card border-start border-warning border-4 h-100">
                        <div class="card-body">
                            <h5 class="card-title text-warning">Waiting</h5>
                            <h3 class="fw-bold">12</h3>
                            <p class="text-muted mb-0">Pending Projects</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card status-card border-start border-info border-4 h-100">
                        <div class="card-body">
                            <h5 class="card-title text-info">Assigned</h5>
                            <h3 class="fw-bold">12</h3>
                            <p class="text-muted mb-0">Ongoing Projects</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Projects Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Project</th>
                                    <th>Team</th>
                                    <th>Status</th>
                                    <th>Progress</th>
                                    <th>Due Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Website Redesign</td>
                                    <td>Design Team</td>
                                    <td><span class="badge bg-success">Completed</span></td>
                                    <td>
                                        <div class="progress" style="height: 6px;">
                                            <div class="progress-bar bg-success" style="width: 100%"></div>
                                        </div>
                                    </td>
                                    <td>May 15, 2023</td>
                                    <td><button class="btn btn-sm btn-outline-primary">View</button></td>
                                </tr>
                                <tr>
                                    <td>Mobile App Development</td>
                                    <td>Dev Team</td>
                                    <td><span class="badge bg-info">Assigned</span></td>
                                    <td>
                                        <div class="progress" style="height: 6px;">
                                            <div class="progress-bar bg-info" style="width: 65%"></div>
                                        </div>
                                    </td>
                                    <td>June 30, 2023</td>
                                    <td><button class="btn btn-sm btn-outline-primary">View</button></td>
                                </tr>
                                <tr>
                                    <td>Market Research</td>
                                    <td>Marketing</td>
                                    <td><span class="badge bg-warning">Waiting</span></td>
                                    <td>
                                        <div class="progress" style="height: 6px;">
                                            <div class="progress-bar bg-warning" style="width: 30%"></div>
                                        </div>
                                    </td>
                                    <td>July 15, 2023</td>
                                    <td><button class="btn btn-sm btn-outline-primary">View</button></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </section>


    <!-- Footer -->
    <section class="footer text-light">
        <div class="container">
            <div class="row" data-aos="fade-right">
                <div class="col-lg-3 py-4 py-md-5">
                    <div class="d-flex align-items-center">
                        <h4 class="">GigNext</h4>
                    </div>
                    <p class="py-3 para-light">Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus animi repudiandae explicabo esse maxime, impedit rem voluptatibus amet error quas.</p>
                    <div class="d-flex">
                        <div class="me-3">
                            <a href="#your-link">
                                <i class="fab fa-facebook-f fa-2x py-2"></i>
                            </a>
                        </div>
                        <div class="me-3">
                            <a href="#your-link">
                                <i class="fab fa-twitter fa-2x py-2"></i>
                            </a>
                        </div>
                        <div class="me-3">
                            <a href="#your-link">
                                <i class="fab fa-instagram fa-2x py-2"></i>
                            </a>
                        </div>
                    </div>
                </div> <!-- end of col -->

                <div class="col-lg-3 py-4 py-md-5">
                    <div>
                        <h4 class="py-2">Quick Links</h4>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#about">
                                <p class="ms-3">About</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#">
                                <p class="ms-3">Hire</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#">
                                <p class="ms-3">earn money</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#">
                                <p class="ms-3">Contact</p>
                            </a>
                        </div>
                    </div>
                </div> <!-- end of col -->

                <div class="col-lg-3 py-4 py-md-5">
                    <div>
                        <h4 class="py-2">Useful Links</h4>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="privacy.html">
                                <p class="ms-3">Privacy</p>
                            </a>

                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="terms.html" target="_blank">
                                <p class="ms-3">Terms</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#your-link">
                                <p class="ms-3">Disclaimer</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#your-link">
                                <p class="ms-3">FAQ</p>
                            </a>
                        </div>
                    </div>
                </div> <!-- end of col -->

                <div class="col-lg-3 py-4 py-md-5">
                    <div class="d-flex align-items-center">
                        <h4>Newsletter</h4>
                    </div>
                    <p class="py-3 para-light">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam, ab.</p>
                    <div class="d-flex align-items-center">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control p-2" placeholder="Enter Email" aria-label="Recipient's email">
                            <button class="btn-secondary text-light"><i class="fas fa-envelope fa-lg"></i></button>
                        </div>
                    </div>
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </section> <!-- end of footer -->


    <!-- Bottom -->
    <div class="bottom py-2 text-light">
        <div class="container d-flex justify-content-between">
            <div>
                <p>Copyright ©GigNext</p><br>
                <p>Devloped By: <b>Ritesh Doibale and Prashant Bhosale</b> </p>
            </div>
            <div>
                <i class="fab fa-cc-visa fa-lg p-1"></i>
                <i class="fab fa-cc-mastercard fa-lg p-1"></i>
                <i class="fab fa-cc-paypal fa-lg p-1"></i>
                <i class="fab fa-cc-amazon-pay fa-lg p-1"></i>
            </div>
        </div> <!-- end of container -->
    </div> <!-- end of bottom -->


    <!-- Back To Top Button -->
    <button onclick="topFunction()" id="myBtn">
        <img src="assets/images/up-arrow.png" alt="alternative">
    </button>
    <!-- end of back to top button -->



    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="./js/bootstrap.min.js"></script><!-- Bootstrap framework -->
    <script src="./js/purecounter.min.js"></script> <!-- Purecounter counter for statistics numbers -->
    <script src="./js/swiper.min.js"></script><!-- Swiper for image and text sliders -->
    <script src="./js/aos.js"></script><!-- AOS on Animation Scroll -->
    <script src="./js/script.js"></script> <!-- Custom scripts -->
</body>

</html>