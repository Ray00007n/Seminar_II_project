<?php

session_start();

include("/xampp/htdocs/GigNext/components/conn.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require 'PHPMailer/PHPMailerAutoload.php';
    require 'credential.php';

    // Get form data
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $mobileNo = $_POST['mobileno'] ?? '';
    $message = $_POST['message'] ?? '';
    $userId = null;

    // Check if username is set in session
    if (isset($_SESSION["username"])) {
        $sql = "SELECT user_id FROM users WHERE username = ?";
        // Prepare and bind
        $stmt = $con->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("s", $_SESSION["username"]);
            // Execute the statement
            $stmt->execute();
            // Bind the result
            $stmt->bind_result($uid);
            if ($stmt->fetch()) {
                // Successfully fetched user_id
                $userId = $uid;
            }
            $stmt->close(); // Close the statement
        } else {
            echo "Error preparing statement: " . $con->error;
        }
    } else {
        echo "Username not set in session.";
    }

    // Prepare the insert statement
    $stmt1 = $con->prepare("INSERT INTO customerqueries (user_id, name, mobile_no, email, query) VALUES (?, ?, ?, ?, ?)");
    if ($stmt1) {
        // Bind parameters
        $stmt1->bind_param("isiss", $userId, $name, $mobileNo, $email, $message);

        // Execute the statement
        if ($stmt1->execute()) {
            // Set up PHPMailer
            $mail = new PHPMailer;
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = EMAIL;
            $mail->Password = PASS;
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom(EMAIL, 'GigNext ltd');
            $mail->addAddress($email, $name);
            $mail->isHTML(true);
            $mail->Subject = "New Message";
            $mail->Body = '<div style="margin: 50px auto; background-color: #fff; padding: 20px; border-radius: 8px; border: black; box-shadow: 0 0 10px rgba(91, 80, 80, 0.1);">YOUR QUERY HAS BEEN REACHED TO US, WE WILL WORK ON IT<br><h3>THANK YOU</h3></div>';
            $mail->AltBody = "YOUR QUERY HAS BEEN REACHED TO US, WE WILL WORK ON IT\nTHANK YOU";

            // Send email and check for success
            if ($mail->send()) {
                echo "Your query has been reached us successfully. You will receive a confirmation email.";
            } else {
                echo "Query submitted, but email could not be sent: " . $mail->ErrorInfo;
            }
        } else {
            echo "Failed to insert query: " . $stmt1->error;
        }
        $stmt1->close(); // Close the insert statement
    } else {
        echo "Error preparing insert statement: " . $con->error;
    }

    // Close the database connection
    $con->close();
}
