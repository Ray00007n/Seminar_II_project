<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



    <!-- Webpage Title -->
    <title>GigNext - Freelancers Market</title>

    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="./css/bootstrap.min.css" rel="stylesheet">
    <link href="./css/fontawesome-all.min.css" rel="stylesheet">
    <link href="./css/aos.min.css" rel="stylesheet">
    <link href="./css/swiper.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" href="./assets/images/favicon.png">
</head>

<body>

    <!-- Navigation -->
    <nav id="navbar" class="navbar navbar-expand-lg fixed-top navbar-dark" aria-label="Main navigation">
        <div class="container">

            <!-- Image Logo -->
            <!-- <a class="navbar-brand logo-image" href="index.php"><img src="images/logo.svg" alt="alternative"></a> -->

            <!-- Text Logo - Use this if you don't have a graphic logo -->
            <a class="navbar-brand logo-text" href="index.php">GigNext</a>

            <button class="navbar-toggler p-0 border-0" type="button" id="navbarSideCollapse" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ms-auto navbar-nav-scroll">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user.php">Hire</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="freelancer.php">earn money</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" id="dropdown01" data-bs-toggle="dropdown" aria-expanded="false" href="#">Drop</a>

                        <ul class="dropdown-menu" aria-labelledby="dropdown01">
                            <li><a class="dropdown-item" href="article.php">Article Details</a></li>
                            <li>
                                <div class="dropdown-divider"></div>
                            </li>
                            <li><a class="dropdown-item" href="terms.php">Terms Conditions</a></li>
                            <li>
                                <div class="dropdown-divider"></div>
                            </li>
                            <li><a class="dropdown-item" href="privacy.php">Privacy Policy</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact</a>
                    </li>

                    <?php
                    session_start();
                    if (!isset($_SESSION["username"])) {
                    ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login_n_signup.php">login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login_n_signup.php">sign up</a>
                        </li>
                </ul>
            <?php
                    } else {
            ?>
                <li><a class="btn btn-primary me-2" href="logout.php">Logout</a></li>
            <?php

                    }

            ?>

            <li><a class="btn btn-primary" href="user.php#add-
            project">Upload Project</a></li>


            <?php

            ?>


            </div> <!-- end of navbar-collapse -->
        </div> <!-- end of container -->
    </nav> <!-- end of navbar -->
    <!-- end of navigation -->



    <!-- Home -->
    <section class="home py-5 d-flex align-items-center" id="header">
        <div class="container text-light py-5" data-aos="fade-right">
            <h1 class="headline">Best <span class="home_text">Freelancer Market</span><br>On Internet</h1>
            <p class="para para-light py-3">The best freelancer markets on the internet provide a platform where skilled professionals and clients connect for a wide range of projects.</p>

            <div class="my-3">
                <a class="btn" href="freelancer.php">Become a Freelancer</a>
            </div>
            <div class="my-3">
                <a class="btn" href="user.php">Hire a freelancer</a>
            </div>
        </div> <!-- end of container -->
    </section> <!-- end of home -->


    <!-- Information -->
    <section class="information">
        <div class="container-fluid">
            <div class="row text-light">
                <div class="col-lg-4 text-center p-5" data-aos="zoom-in">
                    <i class="fas fa-tachometer-alt fa-3x p-2"></i>
                    <h4 class="py-3">Fast task completion</h4>
                    <p class="para-light">platforms provide tools for direct communication, milestone tracking, and secure payments!</p>
                </div>
                <div class="col-lg-4 text-center p-5" data-aos="zoom-in">
                    <i class="fas fa-clock fa-3x p-2"></i>
                    <h4 class="py-3">U can hire anytime</h4>
                    <p class="para-light">you hire skilled professionals anytime for fast, reliable task completion.!</p>
                </div>
                <div class="col-lg-4 text-center p-5 text-dark" data-aos="zoom-in">
                    <i class="fas fa-headset fa-3x p-2"></i>
                    <h4 class="py-3">24/7 Support </h4>
                    <p class="para-light">Get 24/7 support on GigNext to ensure your projects run smoothly at any hour.!</p>
                </div>
            </div>
        </div> <!-- end of container -->
    </section> <!-- end of information -->


    <!-- About -->
    <section class="about d-flex align-items-center text-light py-5" id="about">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col-lg-7" data-aos="fade-right">
                    <p>ABOUT US</p>
                    <h1>We are top internet <br> service company</h1>
                    <p class="py-2 para-light">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non sed accusantium aut dolores inventore architecto modi cupiditate eligendi corporis, illum illo culpa. Reiciendis, molestias. Illum voluptatum quisquam ad veritatis dolorem.</p>
                    <p class="py-2 para-light">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non sed accusantium aut dolores inventore architecto modi cupiditate eligendi corporis, illum illo culpa. Reiciendis, molestias. Illum voluptatum quisquam ad veritatis dolorem.</p>

                    <div class="my-3">
                        <a class="btn" href="#your-link">Learn More</a>
                    </div>
                </div>
                <div class="col-lg-5 text-center py-4 py-sm-0" data-aos="fade-down">
                    <img class="img-fluid" src="./assets/images/about.jpg" alt="about">
                </div>
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </section> <!-- end of about -->


    <!-- Hire -->
    <section class="Hire d-flex align-items-center py-5" id="Hire">
        <div class="container text-light">
            <div class="text-center pb-4">
                <p>OUR Hire</p>
                <h2 class="py-2">Explore unlimited possibilities</h2>
            </div>
            <div class="row gy-4 py-2" data-aos="zoom-in">
                <div class="col-lg-4">
                    <div class="card bg-transparent">
                        <i class="fas fa-terminal fa-2x"></i>
                        <h4 class="py-2">Programming & Tech</h4>
                        <p class="para-light">Get expert coding, app development, website creation, and tech support. Your idea, our code.
                        </p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card bg-transparent">
                        <i class="fas fa-tv fa-2x"></i>
                        <h4 class="py-2">Graphics & Design</h4>
                        <p class="para-light">Eye-catching logos, branding, and designs that make your business stand out.


                        </p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card bg-transparent">
                        <i class="fas fa-comments-dollar fa-2x"></i>
                        <h4 class="py-2">Digital Marketing</h4>
                        <p class="para-light">Boost your brand visibility with SEO, social media, and performance-driven campaigns.
                        </p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card bg-transparent">
                        <i class="fas fa-language fa-2x"></i>
                        <h4 class="py-2">Writing & Translation</h4>
                        <p class="para-light">Professional writing, editing, and multilingual translations tailored to your needs.
                        </p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card bg-transparent">
                        <i class="fas fa-file-video fa-2x"></i>
                        <h4 class="py-2">Video & Animation</h4>
                        <p class="para-light">Bring your vision to life with high-quality video editing, animation, and motion graphics.
                        </p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card bg-transparent">
                        <i class="fas fa-star-of-life fa-2x"></i>
                        <h4 class="py-2">AI Services</h4>
                        <p class="para-light">Explore AI tools, chatbots, and automation that elevate your business efficiency.
                        </p>
                    </div>
                </div>
            </div> <!-- end of row -->
            <div class="my-3">
                <a class="btn " href="user.php">Hire a freelancer</a>
            </div>
        </div> <!-- end of container -->
    </section> <!-- end of Hire -->


    <!-- earn money -->
    <section class="plans earn money d-flex align-items-center py-5" id="plans">
        <div class="container text-light">
            <div class="text-center pb-4">
                <p>BECOME A FREELANCER</p>
                <h2 class="py-2">Explore unlimited possibilities</h2>
                <p class="para-light">
                    Turn your skills into income. Work on your own terms, connect with global clients, and grow your career in the freelancing world. The freedom to choose and the power to succeed—starts here.
                </p>
            </div>


            <div class="col">
                <div class="card bg-transparent px-4">
                    <h4 class="py-2">ADVANTAGES OF FREELANCING</h4>
                    <p class="py-3">Freelancing offers flexibility, independence, and the opportunity to grow professionally.</p>

                    <div class="block d-flex align-items-center">
                        <p class="pe-2"><i class="far fa-check-circle fa-1x"></i></p>
                        <p>Work from anywhere at your own schedule.</p>
                    </div>
                    <div class="block d-flex align-items-center">
                        <p class="pe-2"><i class="far fa-check-circle fa-1x"></i></p>
                        <p>Choose projects that match your skills and interests.</p>
                    </div>
                    <div class="block d-flex align-items-center">
                        <p class="pe-2"><i class="far fa-check-circle fa-1x"></i></p>
                        <p>Build a diverse portfolio and gain experience fast.</p>
                    </div>
                    <div class="block d-flex align-items-center">
                        <p class="pe-2"><i class="far fa-check-circle fa-1x"></i></p>
                        <p>Earn more by working with multiple clients globally.</p>
                    </div>
                </div>


                <div class="my-3">
                    <a class="btn" href="newfreelancer.php"> earn money</a>
                </div>
            </div>
        </div>


        </div> <!-- end of row -->
        </div> <!-- end of container -->
    </section> <!-- end of earn money -->


    <!-- Work -->
    <section class="work d-flex align-items-center py-5">
        <div class="container-fluid text-light">
            <div class="row">
                <div class="col-lg-6 d-flex align-items-center" data-aos="fade-right">
                    <img class="img-fluid" src="./assets/images/work.jpg" alt="work">
                </div>
                <div class="col-lg-5 d-flex align-items-center px-4 py-3" data-aos="">
                    <div class="row">
                        <div class="text-center text-lg-start py-4 pt-lg-0">
                            <p>OUR WORK</p>
                            <h2 class="py-2">Explore unlimited possibilities</h2>
                            <p class="para-light">
                                Turn your skills into income. Work on your own terms, connect with global clients, and grow your career in the freelancing world. The freedom to choose and the power to succeed—starts here.
                            </p>
                        </div>
                        <div class="container" data-aos="fade-up">
                            <div class="row g-5">
                                <div class="col-6 text-start">
                                    <i class="fas fa-briefcase fa-2x text-start"></i>
                                    <h2 class="purecounter" data-purecounter-start="0" data-purecounter-end="1258" data-purecounter-duration="3">1</h2>
                                    <p>PROJECTS COMPLETED</p>
                                </div>
                                <div class="col-6">
                                    <i class="fas fa-award fa-2x"></i>
                                    <h2 class="purecounter" data-purecounter-start="0" data-purecounter-end="150" data-purecounter-duration="3">1</h2>
                                    <p>AWARDS</p>
                                </div>
                                <div class="col-6">
                                    <i class="fas fa-users fa-2x"></i>
                                    <h2 class="purecounter" data-purecounter-start="0" data-purecounter-end="1255" data-purecounter-duration="3">1</h2>
                                    <p>CUSTOMER ACTIVE</p>
                                </div>
                                <div class="col-6">
                                    <i class="fas fa-clock fa-2x"></i>
                                    <h2 class="purecounter" data-purecounter-start="0" data-purecounter-end="1157" data-purecounter-duration="3">1</h2>
                                    <p>GOOD REVIEWS</p>
                                </div>
                            </div>
                        </div> <!-- end of container -->
                    </div> <!-- end of row -->
                </div> <!-- end of col-lg-5 -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </section> <!-- end of work -->


    <!-- Testimonials -->
    <div class="slider-1 testimonial text-light d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="text-center w-lg-75 m-auto pb-4">

                    <h2 class="py-2">What Our Clients Say</h2>
                    <p class="para-light">
                        We’re proud to partner with top talent around the world. Here’s what clients have shared about working with our freelancers.
                    </p>
                </div>
            </div>
            <div class="row p-2" data-aos="zoom-in">
                <div class="col-lg-12">

                    <!-- Card Slider -->
                    <div class="slider-container">
                        <div class="swiper-container card-slider">
                            <div class="swiper-wrapper">

                                <!-- Slide 1 -->
                                <div class="swiper-slide">
                                    <div class="testimonial-card p-4">
                                        <p>“The developer I hired was outstanding. Delivered a fully functional web app ahead of schedule. I’ll definitely be back for future projects.”</p>
                                        <div class="d-flex pt-4">
                                            <div>
                                                <img class="avatar" src="./assets/images/usr1.jpeg" alt="testimonial">
                                            </div>
                                            <div class="ms-3 pt-2">
                                                <h6>Marlene Visconte</h6>
                                                <p>General Manager - Scouter</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Slide 2 -->
                                <div class="swiper-slide">
                                    <div class="testimonial-card p-4">
                                        <p>“Our brand needed a design refresh and the results were beyond our expectations. Creative, fast, and professional.”</p>
                                        <div class="d-flex pt-4">
                                            <div>
                                                <img class="avatar" src="./assets/images/usr1.jpeg" alt="testimonial">
                                            </div>
                                            <div class="ms-3 pt-2">
                                                <h6>John Spiker</h6>
                                                <p>Team Leader - Vanquish</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Slide 3 -->
                                <div class="swiper-slide">
                                    <div class="testimonial-card p-4">
                                        <p>“The animation team was amazing! They brought our concept to life with smooth, stunning visuals. Communication was clear throughout.”</p>
                                        <div class="d-flex pt-4">
                                            <div>
                                                <img class="avatar" src="./assets/images/usr1.jpeg" alt="testimonial">
                                            </div>
                                            <div class="ms-3 pt-2">
                                                <h6>Stella Virtuoso</h6>
                                                <p>Design Chief - Upscale</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Slide 4 -->
                                <div class="swiper-slide">
                                    <div class="testimonial-card p-4">
                                        <p>“Working with freelancers here has saved us time and money. We’ve seen a 35% boost in productivity since onboarding our remote team.”</p>
                                        <div class="d-flex pt-4">
                                            <div>
                                                <img class="avatar" src="./assets/images/usr1.jpeg" alt="testimonial">
                                            </div>
                                            <div class="ms-3 pt-2">
                                                <h6>Mike Tim</h6>
                                                <p>Investor - TechGroww</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <!-- Arrows -->
                            <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div>
                        </div>
                    </div>
                    <!-- End of Card Slider -->

                </div>
            </div>
        </div>
    </div>

    <!-- Newsletter -->
    <section class="newsletter text-light py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 text-center text-lg-start" data-aos="fade-right">
                    <h4 class="py-1">Subscribe to Our Newsletter</h4>
                    <p class="para-light">
                        Stay updated with the latest freelance tips, platform updates, and exclusive opportunities. Join thousands of professionals growing their careers with us.
                    </p>
                </div>
                <div class="col-lg-6 d-flex align-items-center" data-aos="fade-down">
                    <div class="input-group my-3">
                        <input type="text" id="email1" class="form-control p-2" placeholder="Enter your email address" aria-label="Recipient's email">
                        <button class="btn-secondary text-light" type="button" onclick="sendmail()">Subscribe</button>
                    </div>
                </div>
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </section> <!-- end of newsletter -->


    <!-- Contact -->
    <section class="contact d-flex align-items-center py-5" id="contact">
        <div class="container-fluid text-light">
            <div class="row">
                <div class="col-lg-6 d-flex justify-content-center justify-content-lg-end align-items-center px-lg-5" data-aos="fade-right">
                    <div style="width:90%">
                        <div class="text-center text-lg-start py-4 pt-lg-0">
                            <p>CONTACT</p>
                            <h2 class="py-2">Send Your Query</h2>
                            <p class="para-light" id="sentquery">
                                Have questions or need assistance? We’re here to help. Send us your message and our team will get back to you as soon as possible.
                            </p>
                        </div>
                        <div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group py-2">
                                        <input type="text" class="form-control form-control-input" id="qname" placeholder="Enter name">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group py-2">
                                        <input type="text" class="form-control form-control-input" id="qmobileno" placeholder="Enter phone number">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group py-1">
                                <input type="email" class="form-control form-control-input" id="qemail" placeholder="Enter email">
                            </div>
                            <div class="form-group py-2">
                                <textarea class="form-control form-control-input" id="qmessage" rows="6" placeholder="Message"></textarea>
                            </div>
                        </div>
                        <div class="my-3">
                            <button class="btn form-control-submit-button" onclick="submitQuery()">Submit</button>
                        </div>
                    </div> <!-- end of div -->
                </div> <!-- end of col -->
                <div class="col-lg-6 d-flex align-items-center" data-aos="fade-down">
                    <img class="img-fluid d-none d-lg-block" src="./assets/images/contact.jpg" alt="contact">
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </section>
    <!--  end of contact -->


    <!-- Location -->
    <section class="location text-light py-5">
        <div class="container" data-aos="zoom-in">
            <div class="row">

                <div class="col-lg-3 d-flex align-items-center">
                    <div class="p-2"><i class="fas fa-mobile-alt fa-3x"></i></div>
                    <div class="ms-2">
                        <h6>CALL FOR QUERY</h6>
                        <p>(800) 265 216 2020</p>
                    </div>
                </div>
                <div class="col-lg-3 d-flex align-items-center">
                    <div class="p-2"><i class="far fa-envelope fa-3x"></i></div>
                    <div class="ms-2">
                        <h6>SEND US MESSAGE</h6>
                        <p>infodemofile@example.com</p>
                    </div>
                </div>

            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </section> <!-- end of location -->


    <!-- Footer -->
    <section class="footer text-light">
        <div class="container">
            <div class="row" data-aos="fade-right">
                <div class="col-lg-3 py-4 py-md-5">
                    <div class="d-flex align-items-center">
                        <h4 class="">GigNext</h4>
                    </div>
                    <p class="py-3 para-light">
                        GigNext connects talented freelancers with businesses worldwide. We make it easy to hire or work remotely with full flexibility and trust.
                    </p>
                    <div class="d-flex">
                        <div class="me-3">
                            <a href="#your-link">
                                <i class="fab fa-facebook-f fa-2x py-2"></i>
                            </a>
                        </div>
                        <div class="me-3">
                            <a href="#your-link">
                                <i class="fab fa-twitter fa-2x py-2"></i>
                            </a>
                        </div>
                        <div class="me-3">
                            <a href="#your-link">
                                <i class="fab fa-instagram fa-2x py-2"></i>
                            </a>
                        </div>
                    </div>
                </div> <!-- end of col -->

                <div class="col-lg-3 py-4 py-md-5">
                    <div>
                        <h4 class="py-2">Quick Links</h4>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#about">
                                <p class="ms-3">About</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#">
                                <p class="ms-3">Hire</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#">
                                <p class="ms-3">earn money</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#">
                                <p class="ms-3">Contact</p>
                            </a>
                        </div>
                    </div>
                </div> <!-- end of col -->

                <div class="col-lg-3 py-4 py-md-5">
                    <div>
                        <h4 class="py-2">Useful Links</h4>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="privacy.php">
                                <p class="ms-3">Privacy</p>
                            </a>

                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="terms.php" target="_blank">
                                <p class="ms-3">Terms</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#your-link">
                                <p class="ms-3">Disclaimer</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#your-link">
                                <p class="ms-3">FAQ</p>
                            </a>
                        </div>
                    </div>
                </div> <!-- end of col -->

                <div class="col-lg-3 py-4 py-md-5">
                    <div class="d-flex align-items-center">
                        <h4>Newsletter</h4>
                    </div>
                    <p class="para-light">
                        Stay updated with the latest freelance tips, platform updates, and exclusive opportunities. Join thousands of professionals growing their careers with us.
                    </p>
                    <div class="d-flex align-items-center">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control p-2" placeholder="Enter Email" id="email2" aria-label="Recipient's email">
                            <button class="btn-secondary text-light" onclick="sendmail()"><i class="fas fa-envelope fa-lg"></i></button>
                        </div>
                    </div>

                </div> <!-- end of col -->

            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </section> <!-- end of footer -->


    <!-- Bottom -->
    <div class="bottom py-2 text-light">
        <div class="container d-flex justify-content-between">
            <div>
                <p>Copyright ©GigNext</p><br>
                <p>Devloped By: <b>Ritesh Doibale and Prashant Bhosale</b> </p>
            </div>

        </div> <!-- end of container -->
    </div> <!-- end of bottom -->


    <!-- Back To Top Button -->
    <button onclick="topFunction()" id="myBtn">
        <img src="assets/images/up-arrow.png" alt="alternative">
    </button>
    <!-- end of back to top button -->


    <!-- Scripts -->
    <script>
        function sendmail() {
            var email1 = document.getElementById("email1").value.trim("");
            var email2 = document.getElementById("email2").value.trim("");
            var email;
            if (email1 == '') {
                email = email2;
            } else {
                email = email1;
            }

            const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

            // Additional advanced checks
            if (!emailRegex.test(email)) {
                alert("Invalid email format");
                return;
            }



            xhr = new XMLHttpRequest();
            xhr.open("POST", "sendmail.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById("status").innerHTML = xhr.responseText;
                }
            };
            xhr.send("email=" + encodeURIComponent(email));
        }


        function submitQuery() {
            // Get form data
            const name = document.getElementById('qname').value;
            const email = document.getElementById('qemail').value;
            const mobileNo = document.getElementById('qmobileno').value;
            const message = document.getElementById('qmessage').value;

            // Validate form fields
            if (!name || !email || !mobileNo || !message) {
                alert('Please fill all fields');
                return;
            }

            // Email validation regex
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert('Please enter a valid email address');
                return;
            }

            // Mobile number validation (basic - at least 8 digits)
            if (!/^\d{8,}$/.test(mobileNo)) {
                alert('Please enter a valid mobile number');
                return;
            }

            xhr1 = new XMLHttpRequest();
            xhr1.open("POST", "submitQuery.php", true);
            xhr1.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr1.onreadystatechange = function() {
                if (xhr1.readyState === 4 && xhr1.status === 200) {
                    document.getElementById("sentquery").innerHTML = xhr1.responseText;
                }
            };
            xhr1.send("name=" + encodeURIComponent(name) + "&email=" + encodeURIComponent(email) + "&mobileno=" + encodeURIComponent(mobileNo) + "&message=" + encodeURIComponent(message));
        }
    </script>
    <script src="./js/bootstrap.min.js"></script><!-- Bootstrap framework -->
    <script src="./js/purecounter.min.js"></script> <!-- Purecounter counter for statistics numbers -->
    <script src="./js/swiper.min.js"></script><!-- Swiper for image and text sliders -->
    <script src="./js/aos.js"></script><!-- AOS on Animation Scroll -->
    <script src="./js/script.js"></script> <!-- Custom scripts -->
</body>

</html>