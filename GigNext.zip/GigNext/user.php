<?php
session_start();
if (!isset($_SESSION["username"])) {
    header("location : login_n_signup.php");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- SEO Meta Tags -->
    <meta name="description" content="Your description">
    <meta name="author" content="Your name">

    <!-- OG Meta Tags to improve the way the post looks when you share the page on Facebook, Twitter, LinkedIn -->
    <meta property="og:site_name" content="" /> <!-- website name -->
    <meta property="og:site" content="" /> <!-- website link -->
    <meta property="og:title" content="" /> <!-- title shown in the actual shared post -->
    <meta property="og:description" content="" /> <!-- description shown in the actual shared post -->
    <meta property="og:image" content="" /> <!-- image link, make sure it's jpg -->
    <meta property="og:url" content="" /> <!-- where do you want your post to link to -->
    <meta name="twitter:card" content="summary_large_image"> <!-- to have large image post format in Twitter -->

    <!-- Webpage Title -->
    <title>GigNext - Freelancers Market</title>

    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="./css/bootstrap.min.css" rel="stylesheet">
    <link href="./css/fontawesome-all.min.css" rel="stylesheet">
    <link href="./css/aos.min.css" rel="stylesheet">
    <link href="./css/swiper.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" href="./assets/images/favicon.png">
</head>

<body>

    <!-- Navigation -->
    <nav id="navbar" class="navbar navbar-expand-lg fixed-top navbar-dark" aria-label="Main navigation">
        <div class="container">

            <!-- Image Logo -->
            <!-- <a class="navbar-brand logo-image" href="index.html"><img src="images/logo.svg" alt="alternative"></a> -->

            <!-- Text Logo - Use this if you don't have a graphic logo -->
            <a class="navbar-brand logo-text" href="index.php">GigNext</a>

            <button class="navbar-toggler p-0 border-0" type="button" id="navbarSideCollapse" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ms-auto navbar-nav-scroll">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#add-project">Add project</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#my-projects"> My Projects </a>
                    </li>

                </ul>
                <?php
                
                if (!isset($_SESSION["username"])) {
                    header("location: index.php");
                ?>

                <?php
                } else {
                ?>
                    <li><a class="btn btn-primary me-2" href="logout.php">Logout</a></li>
                <?php

                }

                ?>
            </div> <!-- end of navbar-collapse -->
        </div> <!-- end of container -->
    </nav> <!-- end of navbar -->
    <!-- end of navigation -->


    <!-- Home -->



    <section class="about d-flex align-items-center text-light py-5 " id="add-project">
        <div class="container mt-5 p-4 rounded-3" data-aos="fade-right">
            <div class=" shadow rounded-3">
                <div class="card-header bg-primary">
                    <h4 class="mb-0">Post a New Project</h4>
                </div>
                <div class="card-body">
                    <form action="addProject.php" method="POST">
                        <div class="mb-3">
                            <label for="projectName" class="form-label">Project Name</label>
                            <input type="text" class="form-control" id="projectName" name="project_name" placeholder="Enter project title" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Project Description</label>
                            <textarea class="form-control" id="description" name="project_description" rows="4" placeholder="Describe your project" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="category" class="form-label">Project Category</label>
                            <select class="form-select" id="category" name="project_category" required>
                                <option value="" disabled selected>Select a category</option>
                                <option value="Web Development">Web Development</option>
                                <option value="Mobile App Development">Mobile App Development</option>
                                <option value="Data Science">Data Science</option>
                                <option value="Graphic Design">Graphic Design</option>
                                <option value="Marketing">Marketing</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="freelancer" class="form-label">Assign to Freelancer</label>
                            <select class="form-select" id="freelancer" name="assigned_freelancer">
                                <option value="" selected>Select a freelancer (optional)</option>
                                <!-- These options would typically come from a database -->
                                <option value="freelancer1">John Doe (Web Development)</option>
                                <option value="freelancer2">Jane Smith (Graphic Design)</option>
                                <option value="freelancer3">Mike Johnson (Data Science)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="budget" class="form-label">Estimated Budget (₹)</label>
                            <input type="number" class="form-control" id="budget" name="budget" placeholder="Enter budget" min="0" required>
                        </div>
                        <div class="mb-3">
                            <label for="deadline" class="form-label">Deadline</label>
                            <input type="date" class="form-control" id="deadline" name="deadline" required>
                        </div>
                        <div class="my-3">
                            <button type="submit" class="btn form-control-submit-button">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>




    <!-- my projects -->
    <section class="contact d-flex align-items-center py-5" id="my=projects">
        <div class="container py-4" data-aos="fade-right">
            <!-- Status Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="card status-card border-start border-primary border-4 h-100">
                        <div class="card-body">
                            <h5 class="card-title text-primary">All Projects</h5>
                            <h3 class="fw-bold">42</h3>
                            <p class="text-muted mb-0">Total Projects</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card status-card border-start border-success border-4 h-100">
                        <div class="card-body">
                            <h5 class="card-title text-success">Completed</h5>
                            <h3 class="fw-bold">18</h3>
                            <p class="text-muted mb-0">Finished Projects</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card status-card border-start border-warning border-4 h-100">
                        <div class="card-body">
                            <h5 class="card-title text-warning">Waiting</h5>
                            <h3 class="fw-bold">12</h3>
                            <p class="text-muted mb-0">Pending Projects</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card status-card border-start border-info border-4 h-100">
                        <div class="card-body">
                            <h5 class="card-title text-info">Assigned</h5>
                            <h3 class="fw-bold">12</h3>
                            <p class="text-muted mb-0">Ongoing Projects</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Projects Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Project</th>
                                    <th>Team</th>
                                    <th>Status</th>
                                    <th>Progress</th>
                                    <th>Due Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Website Redesign</td>
                                    <td>Design Team</td>
                                    <td><span class="badge bg-success">Completed</span></td>
                                    <td>
                                        <div class="progress" style="height: 6px;">
                                            <div class="progress-bar bg-success" style="width: 100%"></div>
                                        </div>
                                    </td>
                                    <td>May 15, 2023</td>
                                    <td><button class="btn btn-sm btn-outline-primary">View</button></td>
                                </tr>
                                <tr>
                                    <td>Mobile App Development</td>
                                    <td>Dev Team</td>
                                    <td><span class="badge bg-info">Assigned</span></td>
                                    <td>
                                        <div class="progress" style="height: 6px;">
                                            <div class="progress-bar bg-info" style="width: 65%"></div>
                                        </div>
                                    </td>
                                    <td>June 30, 2023</td>
                                    <td><button class="btn btn-sm btn-outline-primary">View</button></td>
                                </tr>
                                <tr>
                                    <td>Market Research</td>
                                    <td>Marketing</td>
                                    <td><span class="badge bg-warning">Waiting</span></td>
                                    <td>
                                        <div class="progress" style="height: 6px;">
                                            <div class="progress-bar bg-warning" style="width: 30%"></div>
                                        </div>
                                    </td>
                                    <td>July 15, 2023</td>
                                    <td><button class="btn btn-sm btn-outline-primary">View</button></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </section>


    <!-- Footer -->
    <section class="footer text-light">
        <div class="container">
            <div class="row" data-aos="fade-right">
                <div class="col-lg-3 py-4 py-md-5">
                    <div class="d-flex align-items-center">
                        <h4 class="">GigNext</h4>
                    </div>
                    <p class="py-3 para-light">Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus animi repudiandae explicabo esse maxime, impedit rem voluptatibus amet error quas.</p>
                    <div class="d-flex">
                        <div class="me-3">
                            <a href="#your-link">
                                <i class="fab fa-facebook-f fa-2x py-2"></i>
                            </a>
                        </div>
                        <div class="me-3">
                            <a href="#your-link">
                                <i class="fab fa-twitter fa-2x py-2"></i>
                            </a>
                        </div>
                        <div class="me-3">
                            <a href="#your-link">
                                <i class="fab fa-instagram fa-2x py-2"></i>
                            </a>
                        </div>
                    </div>
                </div> <!-- end of col -->

                <div class="col-lg-3 py-4 py-md-5">
                    <div>
                        <h4 class="py-2">Quick Links</h4>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#about">
                                <p class="ms-3">About</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#">
                                <p class="ms-3">Hire</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#">
                                <p class="ms-3">earn money</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#">
                                <p class="ms-3">Contact</p>
                            </a>
                        </div>
                    </div>
                </div> <!-- end of col -->

                <div class="col-lg-3 py-4 py-md-5">
                    <div>
                        <h4 class="py-2">Useful Links</h4>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="privacy.html">
                                <p class="ms-3">Privacy</p>
                            </a>

                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="terms.html" target="_blank">
                                <p class="ms-3">Terms</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#your-link">
                                <p class="ms-3">Disclaimer</p>
                            </a>
                        </div>
                        <div class="d-flex align-items-center py-2">
                            <i class="fas fa-caret-right"></i>
                            <a href="#your-link">
                                <p class="ms-3">FAQ</p>
                            </a>
                        </div>
                    </div>
                </div> <!-- end of col -->

                <div class="col-lg-3 py-4 py-md-5">
                    <div class="d-flex align-items-center">
                        <h4>Newsletter</h4>
                    </div>
                    <p class="py-3 para-light">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam, ab.</p>
                    <div class="d-flex align-items-center">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control p-2" placeholder="Enter Email" aria-label="Recipient's email">
                            <button class="btn-secondary text-light"><i class="fas fa-envelope fa-lg"></i></button>
                        </div>
                    </div>
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </section> <!-- end of footer -->


    <!-- Bottom -->
    <div class="bottom py-2 text-light">
        <div class="container d-flex justify-content-between">
            <div>
                <p>Copyright ©GigNext</p><br>
                <p>Devloped By: <b>Ritesh Doibale and Prashant Bhosale</b> </p>
            </div>
            <div>
                <i class="fab fa-cc-visa fa-lg p-1"></i>
                <i class="fab fa-cc-mastercard fa-lg p-1"></i>
                <i class="fab fa-cc-paypal fa-lg p-1"></i>
                <i class="fab fa-cc-amazon-pay fa-lg p-1"></i>
            </div>
        </div> <!-- end of container -->
    </div> <!-- end of bottom -->


    <!-- Back To Top Button -->
    <button onclick="topFunction()" id="myBtn">
        <img src="assets/images/up-arrow.png" alt="alternative">
    </button>
    <!-- end of back to top button -->



    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="./js/bootstrap.min.js"></script><!-- Bootstrap framework -->
    <script src="./js/purecounter.min.js"></script> <!-- Purecounter counter for statistics numbers -->
    <script src="./js/swiper.min.js"></script><!-- Swiper for image and text sliders -->
    <script src="./js/aos.js"></script><!-- AOS on Animation Scroll -->
    <script src="./js/script.js"></script> <!-- Custom scripts -->
</body>

</html>