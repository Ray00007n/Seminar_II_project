<?php
include("/xampp/htdocs/GigNext/components/conn.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['action']) && $_POST['action'] === 'signup') {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $mobileno = $_POST['mobileno'];
        $password = $_POST['password'];
        $type=$_POST['type'];

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);


        // Check if email already exists
        $checkEmailSql = "SELECT email FROM users WHERE email = ?";
        $stmt = $con->prepare($checkEmailSql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            echo "This email is already registered. Please use a different email.";
        } else {

        $stmt = $con->prepare("INSERT INTO users (username, mobile_number, email, password_hash,role) VALUES (?, ?, ?, ?,?)");
        $stmt->bind_param("sssss", $username, $mobileno, $email, $hashed_password,$type);

          if ($stmt->execute()) {
            echo "<script>alert('Sign-up successful!');</script>";
        } else {
            echo "<script>alert('Sign-up failed. Try again.');</script>";
        } 
        }
       
    }

    if (isset($_POST['action']) && $_POST['action'] === 'login') {
        $username = $_POST['login_username'];
        $password = $_POST['login_password'];

        $stmt = $con->prepare("SELECT password_hash 
FROM users
WHERE username = ? OR email = ?;
");
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($hashed_password);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                echo "<script>alert('Login successful!');</script>";
                session_start();


                $stmt2 = $con->prepare("SELECT role 
                FROM users
                WHERE username = ? OR email = ?;
                ");
                $stmt2->bind_param("ss", $username, $username);
                $stmt2->execute();
                $stmt2->store_result();
                $_SESSION["username"] = $username;
                if ($stmt->num_rows > 0) {
                    $stmt->bind_result($_SESSION["type"]);
                    $stmt->fetch();}

                header("location: index.php");
            } else {
                echo "<script>alert('Invalid password.');</script>";
            }
        } else {
            echo "<script>alert('Username not found.');</script>";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login: Sign up or Signup</title>
    <link rel="stylesheet" href="los.css">
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">
</head>

<body>
    <div id="container" class="container">
        <!-- FORM SECTION -->
        <div class="row">
            <!-- SIGN UP -->

            <div class="col align-items-center flex-col sign-up">
                <form method="post" onsubmit="return validateForm()">
                    <input type="hidden" name="action" value="signup">

                    <div class="form-wrapper align-items-center">
                        <div class="form sign-up">
                            <div class="input-group">
                                <i class='bx bxs-user'></i>
                                <input type="text" id="username" name="username" placeholder="Username">
                                <small id="username-error" class="error-message"></small>
                            </div>
                            <div class="input-group">
                                <i class='bx bx-mail-send'></i>
                                <input type="mobileno" name="mobileno" id="mobileno" placeholder="mobileno">
                                <small id="mobileno-error" class="error-message"></small>
                            </div>
                            <div class="input-group">
                                <i class='bx bx-mail-send'></i>
                                <input type="email" id="email" name="email" placeholder="Email">
                                <small id="email-error" class="error-message"></small>
                            </div>


                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="type" id="inlineRadio1" value="client">
                                <label class="form-check-label" for="inlineRadio1">Client</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="type" id="inlineRadio2" value="freelancer">
                                <label class="form-check-label" for="inlineRadio2">Freelancer</label>
                            </div>

                            <div class="input-group">
                                <i class='bx bxs-lock-alt'></i>
                                <input type="password" id="password" name="password" placeholder="Password">
                                <small id="password-error" class="error-message"></small>
                            </div>
                            <div class="input-group">
                                <i class='bx bxs-lock-alt'></i>
                                <input type="password" id="confirm-password" placeholder="Confirm password">
                                <small id="confirm-password-error" class="error-message"></small>
                            </div>
                            <button type="submit" value="Sign Up">Sig nup</button>
                            <p>
                                <span>Already have an account?</span>
                                <b onclick="toggle()" class="pointer">Sign in here</b>
                            </p>
                        </div>
                    </div>
                </form>
            </div>

            <!-- END SIGN UP -->
            <!-- SIGN IN -->
            <div class="col align-items-center flex-col sign-in">
                <form method="post">
                    <input type="hidden" name="action" value="login">
                    <div class="form-wrapper align-items-center">
                        <div class="form sign-in">
                            <div class="input-group">
                                <i class='bx bxs-user'></i>
                                <input type="text" name="login_username" placeholder="Username">
                            </div>
                            <div class="input-group">
                                <i class='bx bxs-lock-alt'></i>
                                <input type="password" name="login_password" placeholder="Password">
                            </div>


                            <button type="submit">Sig in</button>
                            <p><b>Forgot password?</b></p>
                            <p>
                                <span>Don't have an account?</span>
                                <b onclick="toggle()" class="pointer">Sign up here</b>
                            </p>
                        </div>
                    </div>
                </form>
            </div>
            <!-- END SIGN IN -->
        </div>
        <!-- END FORM SECTION -->
        <!-- CONTENT SECTION -->
        <div class="row content-row">
            <!-- SIGN IN CONTENT -->
            <div class="col align-items-center flex-col">
                <div class="text sign-in">
                    <h2>Welcome</h2>
                </div>
                <div class="img sign-in"></div>
            </div>
            <!-- END SIGN IN CONTENT -->
            <!-- SIGN UP CONTENT -->
            <div class="col align-items-center flex-col">
                <div class="img sign-up"></div>
                <div class="text sign-up">
                    <h2>Join with us</h2>
                </div>
            </div>
            <!-- END SIGN UP CONTENT -->
        </div>
        <!-- END CONTENT SECTION -->
    </div>

    <script src="los.js"></script>
    <script>
        function validateForm() {
            let isValid = true;

            const username = document.getElementById('username');
            const email = document.getElementById('email');
            const mobileno = document.getElementById('mobileno');
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirm-password');

            const usernameError = document.getElementById('username-error');
            const emailError = document.getElementById('email-error');
            const mobilenoError = document.getElementById('mobileno-error');
            const passwordError = document.getElementById('password-error');
            const confirmPasswordError = document.getElementById('confirm-password-error');

            // Username
            if (username.value.trim() === '' || /\d/.test(username.value)) {
                usernameError.textContent = 'Username is required and must not contain numbers';
                isValid = false;
            } else {
                usernameError.textContent = '';
            }

            // Email
            const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if (!emailPattern.test(email.value.trim())) {
                emailError.textContent = 'Enter a valid email';
                isValid = false;
            } else {
                emailError.textContent = '';
            }

            // Mobile
            if (!/^\d{10}$/.test(mobileno.value.trim())) {
                mobilenoError.textContent = 'Enter a valid 10-digit mobile number';
                isValid = false;
            } else {
                mobilenoError.textContent = '';
            }

            // Password
            const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
            if (!passwordPattern.test(password.value.trim())) {
                passwordError.textContent = 'Must be 8+ chars with upper, lower, and number';
                isValid = false;
            } else {
                passwordError.textContent = '';
            }

            // Confirm Password
            if (confirmPassword.value !== password.value) {
                confirmPasswordError.textContent = 'Passwords do not match';
                isValid = false;
            } else {
                confirmPasswordError.textContent = '';
            }

            return isValid;
        }
    </script>
</body>

</html>
</body>

</html>