<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "gignext";

$con=mysqli_connect($host,$username,$password,$dbname);
if(!isset($con)){
    echo mysqli_error($con);
}
?>