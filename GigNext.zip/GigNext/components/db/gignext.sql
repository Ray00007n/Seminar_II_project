-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2025 at 07:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gignext`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_id`, `name`, `email`, `phone`, `address`, `created_at`) VALUES
(1, 'ritesh', 'riteshdoibale6@gmail.com', '555-1234', '123 Elm St, Springfield, IL', '2025-06-28 01:55:06'),
(2, 'Bob Smith', 'bob.smith@example.com', '555-5678', '456 Oak St, Springfield, IL', '2025-06-28 01:55:06'),
(3, 'Charlie Brown', 'charlie.brown@example.com', '555-8765', '789 Pine St, Springfield, IL', '2025-06-28 01:55:06'),
(4, 'Diana Prince', 'diana.prince@example.com', '555-4321', '321 Maple St, Springfield, IL', '2025-06-28 01:55:06');

-- --------------------------------------------------------

--
-- Table structure for table `customerqueries`
--

CREATE TABLE `customerqueries` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `query` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customerqueries`
--

INSERT INTO `customerqueries` (`id`, `user_id`, `name`, `mobile_no`, `email`, `query`, `created_at`) VALUES
(26, NULL, 'jlj ', '9637418521', 'riteshdoibale6@gmail.com', 'hfgjhk', '2025-06-26 15:07:48'),
(27, NULL, 'Ritsh', '9373449263', 'riteshdoibale6@gmail.com', 'vjhbkeqcdsvk', '2025-06-26 15:09:06'),
(28, NULL, 'RItsh', '9373449263', 'riteshdoibale6@gmail.com', 'hellllllllllllllo', '2025-06-26 15:11:17'),
(29, NULL, 'RItesh', '9373449263', 'riteshdoibale6@gmail.com', 'msggg', '2025-06-26 15:14:49'),
(30, NULL, 'Ritesh', '9373449263', 'riteshdoibale6@gmail.com', 'msgg', '2025-06-26 15:22:11');

-- --------------------------------------------------------

--
-- Table structure for table `freelancers`
--

CREATE TABLE `freelancers` (
  `freelancer_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `freelancers`
--

INSERT INTO `freelancers` (`freelancer_id`, `name`, `email`, `phone`, `skills`, `created_at`) VALUES
(1, 'John Doe', 'john.doe@example.com', '555-1111', 'Web Development, Graphic Design', '2025-06-28 01:56:51'),
(2, 'Jane Smith', 'jane.smith@example.com', '555-2222', 'Content Writing, SEO', '2025-06-28 01:56:51'),
(3, 'Mike Johnson', 'mike.johnson@example.com', '555-3333', 'Mobile App Development, UX/UI Design', '2025-06-28 01:56:51'),
(4, 'Emily Davis', 'emily.davis@example.com', '555-4444', 'Data Analysis, Python Programming', '2025-06-28 01:56:51');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `project_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `freelancer_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Pending','In Progress','Completed','Cancelled') DEFAULT 'Pending',
  `budget` decimal(10,2) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`project_id`, `client_id`, `freelancer_id`, `title`, `description`, `status`, `budget`, `start_date`, `end_date`, `created_at`) VALUES
(1, 1, 1, 'E-commerce Website', 'Develop a fully functional e-commerce website.', '', 10000.00, '2023-10-01 00:00:00', '2023-12-01 00:00:00', '2025-06-28 02:00:38'),
(2, 2, 2, 'Blog Content Creation', 'Write and publish 10 blog posts for the client.', '', 3000.00, '2023-10-15 00:00:00', '2023-11-30 00:00:00', '2025-06-28 02:00:38'),
(3, 3, 3, 'Mobile App Development', 'Create a mobile app for iOS and Android.', '', 15000.00, '2023-09-01 00:00:00', '2023-11-15 00:00:00', '2025-06-28 02:00:38'),
(4, 4, 4, 'Data Analysis Project', 'Analyze sales data and provide insights.', '', 5000.00, '2023-10-05 00:00:00', '2023-11-20 00:00:00', '2025-06-28 02:00:38'),
(5, 1, 2, 'SEO Optimization', 'Optimize the website for search engines.', '', 2000.00, '2023-10-10 00:00:00', '2023-11-10 00:00:00', '2025-06-28 02:00:38');

-- --------------------------------------------------------

--
-- Table structure for table `subscribed_emails`
--

CREATE TABLE `subscribed_emails` (
  `email` varchar(255) NOT NULL,
  `subscription_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscribed_emails`
--

INSERT INTO `subscribed_emails` (`email`, `subscription_date`) VALUES
('riteshdoibale6@gmail.com', '2025-06-26 03:50:41'),
('s24_bhosale_prashant@mgmcen.ac.in', '2025-06-26 13:12:23'),
('sd24_doibale_ritesh@mgmcen.ac.in', '2025-06-26 03:55:29');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `mobile_number` varchar(15) DEFAULT NULL,
  `role` enum('client','freelancer','admin') NOT NULL DEFAULT 'client',
  `profile_description` text DEFAULT NULL,
  `profile_photo_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password_hash`, `full_name`, `mobile_number`, `role`, `profile_description`, `profile_photo_url`, `created_at`, `updated_at`, `is_active`) VALUES
(1, 'ritesh', 's24_doibale_ritesh@mgmcen.ac.in', '$2y$10$GnjBFz8OcRRPBqRAC9K/Me/BzUCgwgFDbWdpoCgwHBg6iTxW2pSHa', NULL, '9373449263', 'client', NULL, NULL, '2025-06-18 10:46:34', '2025-06-18 10:46:34', 1),
(2, 'Prashant', 's24_bhosale_prashant@mgmcen.ac.in', '$2y$10$sjVJZ9gWlgDNZdWn2VwpDueK6JBfC0aNeGwTh1xfgTv7RNo2Mhy82', NULL, '9373342655', 'client', NULL, NULL, '2025-06-18 11:32:24', '2025-06-18 11:32:24', 1),
(3, 'admin@example.com', 'riteshdoibale6@gmail.com', '$2y$10$t5QrPBF1bJ6cucdPD4sXZexMSjCCpwOov61EnRRGJoEUEGzdmnvW2', NULL, '9373449263', 'client', NULL, NULL, '2025-06-20 17:31:29', '2025-06-20 17:31:29', 1),
(5, 'rayoo', 'riteshdoibaaale6@gmail.com', '$2y$10$8T2USuMLt6jwNxbHSftvE./XbE1XU0NfqwJSX2sMSIWGqQzn5Dymu', NULL, '9373449263', '', NULL, NULL, '2025-06-26 16:21:49', '2025-06-26 16:21:49', 1),
(6, 'adminaa', 'riiiteshdoibale6@gmail.com', '$2y$10$3t2clRjQjt4DFUdgxFsa3uAROfmKrQN0dUpbHoDUMiuBSXR.TY0fe', NULL, '9373449263', 'freelancer', NULL, NULL, '2025-06-26 16:41:29', '2025-06-26 16:41:29', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `customerqueries`
--
ALTER TABLE `customerqueries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `freelancers`
--
ALTER TABLE `freelancers`
  ADD PRIMARY KEY (`freelancer_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`project_id`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `freelancer_id` (`freelancer_id`);

--
-- Indexes for table `subscribed_emails`
--
ALTER TABLE `subscribed_emails`
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customerqueries`
--
ALTER TABLE `customerqueries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `freelancers`
--
ALTER TABLE `freelancers`
  MODIFY `freelancer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`),
  ADD CONSTRAINT `projects_ibfk_2` FOREIGN KEY (`freelancer_id`) REFERENCES `freelancers` (`freelancer_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
