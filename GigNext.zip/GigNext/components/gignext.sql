-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 14, 2025 at 05:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gignext`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `uid` varchar(250) NOT NULL,
  `msg` varchar(500) NOT NULL,
  `type` int(1) NOT NULL,
  `uid2` varchar(250) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `uid` varchar(250) NOT NULL,
  `likes` int(11) NOT NULL DEFAULT 0,
  `comments` int(11) NOT NULL DEFAULT 0,
  `postid` int(11) NOT NULL DEFAULT 0,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` mediumtext NOT NULL,
  `username` varchar(20) NOT NULL,
  `mobile_no` int(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `mobile_no`, `email`, `password`, `type`) VALUES
('100000000001', 'DevloperRitesh', 2073449263, 'riteshdoibale6@gmail.com', 'password', 'Emplo'),
('100000000002', 'admin', 2147483647, 'riteshdoibale6@gmail.com', '$2y$10$mI.RMKOMEyUwdmJBuHVc1uup9mhpKNxsoCXMEg6snxTHnjXrWwu96', ''),
('100000000003', 'Ritesh', 2147483647, 'riteshdoibale6@gmail.com', '$2y$10$O3kcazreRFOt/hByWM/wJuaf9fg3C4diMWJKlnAqW2E2H9XWt9lXq', ''),
('', 'rayoo', 2147483647, 'riteshdoibale6@gmail.com', '$2y$10$rRbeObDUdWHulLXImN3K/e.3Tov1vZKRUQ/d865xz8Wr2Oqqu/L3q', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `userid` (`userid`) USING HASH,
  ADD UNIQUE KEY `userid_2` (`userid`) USING HASH;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
