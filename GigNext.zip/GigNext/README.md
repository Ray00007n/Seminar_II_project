# send-email-using-smtp-phpmailer-localhost
Sending Emails in PHP from localhost with SMTP Using PHPMailer with attachments  
Download the library from https://github.com/PHPMailer/PHPMailer/tree/5.2-stable    

Follow the tutorial at:  
https://www.youtube.com/watch?v=-B1L0O6S-88  
https://www.youtube.com/watch?v=y14b_RW96s0
