<?php
session_start();
$_SESSION["username"]==NULL;
session_destroy();
header("location: index.php");

?>