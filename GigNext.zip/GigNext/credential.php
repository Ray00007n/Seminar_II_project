<?php
/*Update credentials*/
	define('EMAIL', 'shushilwaghmare800@gmail.com');
	define('PASS', 'mtyq qhsk zsfq wpop');
 ?>